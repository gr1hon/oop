﻿using System;
using System.Collections.Generic;
using System.Numerics;
using System.Windows.Forms;
using Npgsql;

namespace lab2
{
    public class Arcade : Game
    {
        private int Score { get; set; }
        private int Level { get; set; }

        
        private List<int> Levels { get; } = new List<int>();

        public Arcade(string title, string genre, Player player, int score, int level)
            : base(title, genre, player)
        {
            Score = score;
            Level = level;
            InitializeLevels();
        }

        private void InitializeLevels()
        {
            Levels.Add(100);
            for (int i = 0; i < 20; i++)
            {
                Levels.Add(Levels[i] * 2);
            }
        }
        public int GetScore()
        {
            return Score;
        }
        public void SetScore(int score)
        {
            Score = score;
        }
        public int GetLevel()
        {
            return Level;
        }
        public void SetLevel(int level)
        {
            Level = level;
        }

        public void IncreaseScore(int points)
        {
            if (!Paused)
            {
                Score += points;
                while (Level <= Levels.Count && Score > Levels[Level])
                {
                    Level++;
                }
            }
        }

        public void NextLevel()
        {
            if (!Paused && Level < Levels.Count)
            {
                Level++;
                Score = Levels[Level-1];
            }
        }

        override public void SaveProgress()
        {
            using (var connection = new NpgsqlConnection(DatabaseHelper.GetConnectionString()))
            {
                connection.Open();
                string query;
                using (var checkCmd = new NpgsqlCommand(
                   "SELECT COUNT(*) FROM arcade WHERE gameid = @game_id", connection))
                {
                    checkCmd.Parameters.AddWithValue("@game_id", GameId);
                    var count = (long)checkCmd.ExecuteScalar();
                  
                    if (count == 0)
                    {
                        query = @"INSERT INTO arcade (gameid, score, level, playerid) VALUES (@game_id, @score, @level, @player_id);";

                        using (var cmd = new NpgsqlCommand(query, connection))
                        {
                            cmd.Parameters.AddWithValue("@game_id", GameId);
                            cmd.Parameters.AddWithValue("@score", Score);
                            cmd.Parameters.AddWithValue("@level", Level);
                            cmd.Parameters.AddWithValue("@player_id", _Player.PlayerID);

                            cmd.ExecuteNonQuery();
                        }
                       
                    }
                    else
                    {
                        query = @"UPDATE arcade SET score = @score, level = @level WHERE gameid = @game_id;";

                        using (var cmd = new NpgsqlCommand(query, connection))
                        {
                            cmd.Parameters.AddWithValue("@game_id", GameId);
                            cmd.Parameters.AddWithValue("@score", Score);
                            cmd.Parameters.AddWithValue("@level", Level);

                            cmd.ExecuteNonQuery();
                        }
                    }
                }
            }
        }

        override public void LoadProgress()
        {
            using (var connection = new NpgsqlConnection(DatabaseHelper.GetConnectionString()))
            {
                connection.Open();

                string query = @"
            SELECT score, level, gameid
            FROM arcade
            WHERE playerid = @player_id
            ORDER BY arcadeid DESC
            LIMIT 1;";

                using (var cmd = new NpgsqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@player_id", _Player.PlayerID);

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            Score = reader.GetInt32(0);
                            Level = reader.GetInt32(1);
                            GameId = reader.GetInt32(2);
                            _Player.LastGameSessionID = GameId;
                        }
                        else
                        {
                            throw new Exception("У Вас нет сохранённых данных!");
                        }
                    }
                }
                using (var updatePlayerCmd = new NpgsqlCommand(
                    "UPDATE player SET lastgamesessionid = @gameId WHERE playerid = @playerId", connection))
                {
                    updatePlayerCmd.Parameters.AddWithValue("gameId", GameId);
                    updatePlayerCmd.Parameters.AddWithValue("playerId", _Player.PlayerID);
                    updatePlayerCmd.ExecuteNonQuery();
                }
            }
        }
        public void DeleteLastArcadeSave()
        {
            if (_Player == null)
            {
                MessageBox.Show("Игрок не авторизован.");
                return;
            }

            using (var connection = new NpgsqlConnection(DatabaseHelper.GetConnectionString()))
            {
                connection.Open();

                // Проверяем, есть ли сохранение в arcade с этим gameid и playerid
                using (var checkCmd = new NpgsqlCommand(
                    "SELECT COUNT(*) FROM arcade WHERE playerid = @pid", connection))
                {
                    checkCmd.Parameters.AddWithValue("pid", _Player.PlayerID);
                    var count = (long)checkCmd.ExecuteScalar();

                    if (count == 0)
                    {
                        MessageBox.Show("Сохранение не найдено.");
                        return;
                    }
                }

                // Удаляем строку из arcade
                using (var deleteCmd = new NpgsqlCommand(
                    "DELETE FROM arcade WHERE arcadeid = (" +
                    "SELECT arcadeid FROM arcade WHERE " +
                    "playerid = @pid ORDER BY arcadeid DESC LIMIT 1 )"
                    , connection))
                {
                    deleteCmd.Parameters.AddWithValue("pid", _Player.PlayerID);
                    deleteCmd.ExecuteNonQuery();
                }

                // Обнуляем lastgamesessionid у игрока
                using (var updateCmd = new NpgsqlCommand(
                    "UPDATE player SET lastgamesessionid = NULL WHERE playerid = @pid", connection))
                {
                    updateCmd.Parameters.AddWithValue("pid", _Player.PlayerID);
                    updateCmd.ExecuteNonQuery();
                }

                MessageBox.Show("Последнее сохранение успешно удалено.");
            }
        }
    }
}