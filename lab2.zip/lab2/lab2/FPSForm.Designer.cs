﻿using System.Windows.Forms;

namespace lab2
{
    partial class FPSForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblHealth = new System.Windows.Forms.Label();
            this.lblAmmo = new System.Windows.Forms.Label();
            this.btnHeal = new System.Windows.Forms.Button();
            this.btnShoot = new System.Windows.Forms.Button();
            this.btnPause = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnLoad = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblPause = new System.Windows.Forms.Label();
            this.btnTakeDamage = new System.Windows.Forms.Button();
            this.txtDamageInput = new System.Windows.Forms.TextBox();
            this.btnDeleteLastSave = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblHealth
            // 
            this.lblHealth.AutoSize = true;
            this.lblHealth.Location = new System.Drawing.Point(25, 32);
            this.lblHealth.Name = "lblHealth";
            this.lblHealth.Size = new System.Drawing.Size(71, 16);
            this.lblHealth.TabIndex = 0;
            this.lblHealth.Text = "Здоровье";
            // 
            // lblAmmo
            // 
            this.lblAmmo.AutoSize = true;
            this.lblAmmo.Location = new System.Drawing.Point(28, 83);
            this.lblAmmo.Name = "lblAmmo";
            this.lblAmmo.Size = new System.Drawing.Size(65, 16);
            this.lblAmmo.TabIndex = 1;
            this.lblAmmo.Text = "Патроны";
            // 
            // btnHeal
            // 
            this.btnHeal.Location = new System.Drawing.Point(28, 130);
            this.btnHeal.Name = "btnHeal";
            this.btnHeal.Size = new System.Drawing.Size(131, 34);
            this.btnHeal.TabIndex = 2;
            this.btnHeal.Text = "Подлечиться";
            this.btnHeal.UseVisualStyleBackColor = true;
            this.btnHeal.Click += new System.EventHandler(this.btnHeal_Click);
            // 
            // btnShoot
            // 
            this.btnShoot.Location = new System.Drawing.Point(28, 237);
            this.btnShoot.Name = "btnShoot";
            this.btnShoot.Size = new System.Drawing.Size(131, 34);
            this.btnShoot.TabIndex = 3;
            this.btnShoot.Text = "Выстрел!";
            this.btnShoot.UseVisualStyleBackColor = true;
            this.btnShoot.Click += new System.EventHandler(this.btnShoot_Click);
            // 
            // btnPause
            // 
            this.btnPause.Location = new System.Drawing.Point(435, 237);
            this.btnPause.Name = "btnPause";
            this.btnPause.Size = new System.Drawing.Size(124, 34);
            this.btnPause.TabIndex = 4;
            this.btnPause.Text = "Пауза";
            this.btnPause.UseVisualStyleBackColor = true;
            this.btnPause.Click += new System.EventHandler(this.btnPause_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(435, 277);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(124, 34);
            this.btnSave.TabIndex = 5;
            this.btnSave.Text = "Сохранить";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnLoad
            // 
            this.btnLoad.Location = new System.Drawing.Point(435, 317);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(124, 34);
            this.btnLoad.TabIndex = 6;
            this.btnLoad.Text = "Загрузить";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(435, 357);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(124, 34);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "Выход";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblPause
            // 
            this.lblPause.AutoSize = true;
            this.lblPause.Location = new System.Drawing.Point(244, 55);
            this.lblPause.Name = "lblPause";
            this.lblPause.Size = new System.Drawing.Size(0, 16);
            this.lblPause.TabIndex = 8;
            // 
            // btnTakeDamage
            // 
            this.btnTakeDamage.Location = new System.Drawing.Point(28, 170);
            this.btnTakeDamage.Name = "btnTakeDamage";
            this.btnTakeDamage.Size = new System.Drawing.Size(131, 34);
            this.btnTakeDamage.TabIndex = 9;
            this.btnTakeDamage.Text = "Получить урон";
            this.btnTakeDamage.UseVisualStyleBackColor = true;
            this.btnTakeDamage.Click += new System.EventHandler(this.btnTakeDamage_Click);
            // 
            // txtDamageInput
            // 
            this.txtDamageInput.Location = new System.Drawing.Point(182, 176);
            this.txtDamageInput.Name = "txtDamageInput";
            this.txtDamageInput.Size = new System.Drawing.Size(131, 22);
            this.txtDamageInput.TabIndex = 10;
            // 
            // btnDeleteLastSave
            // 
            this.btnDeleteLastSave.Location = new System.Drawing.Point(284, 277);
            this.btnDeleteLastSave.Name = "btnDeleteLastSave";
            this.btnDeleteLastSave.Size = new System.Drawing.Size(102, 74);
            this.btnDeleteLastSave.TabIndex = 11;
            this.btnDeleteLastSave.Text = "Удалить последнее сохранение";
            this.btnDeleteLastSave.UseVisualStyleBackColor = true;
            this.btnDeleteLastSave.Click += new System.EventHandler(this.btnDeleteLastSave_Click);
            // 
            // FPSForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 450);
            this.Controls.Add(this.btnDeleteLastSave);
            this.Controls.Add(this.txtDamageInput);
            this.Controls.Add(this.btnTakeDamage);
            this.Controls.Add(this.lblPause);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnLoad);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnPause);
            this.Controls.Add(this.btnShoot);
            this.Controls.Add(this.btnHeal);
            this.Controls.Add(this.lblAmmo);
            this.Controls.Add(this.lblHealth);
            this.Name = "FPSForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Шутер";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblHealth;
        private System.Windows.Forms.Label lblAmmo;
        private System.Windows.Forms.Button btnHeal;
        private System.Windows.Forms.Button btnShoot;
        private System.Windows.Forms.Button btnPause;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblPause;
        private System.Windows.Forms.Button btnTakeDamage;
        private System.Windows.Forms.TextBox txtDamageInput;
        private Button btnDeleteLastSave;
    }
}