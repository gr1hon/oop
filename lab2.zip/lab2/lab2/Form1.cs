﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Drawing;
using System.Numerics;
using System.Windows.Forms;

namespace lab2
{
    public partial class Form1 : Form
    {
        public Player _currentPlayer;
        public Form1()
        {
            InitializeComponent();
            this.Load += Form1_Load;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                SetupUI();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка инициализации БД: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
        }

        private void SetupUI()
        {
            // Настройка 
            this.Size = new System.Drawing.Size(300, 350);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Надпись "Выберите игру"
            Label titleLabel = new Label();
            titleLabel.Text = "Выберите игру";
            titleLabel.Font = new System.Drawing.Font("Arial", 16, System.Drawing.FontStyle.Bold);
            titleLabel.AutoSize = true;
            titleLabel.Location = new System.Drawing.Point(60, 20);
            this.Controls.Add(titleLabel);

            // Кнопка "Аркада"
            Button arcadeBtn = new Button();
            arcadeBtn.Text = "Аркада";
            arcadeBtn.Size = new System.Drawing.Size(150, 40);
            arcadeBtn.Location = new System.Drawing.Point(70, 70);
            arcadeBtn.Click += ArcadeBtn_Click;
            this.Controls.Add(arcadeBtn);

            // Кнопка "Шутер"
            Button fpsBtn = new Button();
            fpsBtn.Text = "Шутер";
            fpsBtn.Size = new System.Drawing.Size(150, 40);
            fpsBtn.Location = new System.Drawing.Point(70, 120);
            fpsBtn.Click += FPSBtn_Click;
            this.Controls.Add(fpsBtn);

            // Кнопка "Выход"
            Button exitBtn = new Button();
            exitBtn.Text = "Выход";
            exitBtn.Size = new System.Drawing.Size(150, 40);
            exitBtn.Location = new System.Drawing.Point(70, 170);
            exitBtn.Click += ExitBtn_Click;
            this.Controls.Add(exitBtn);

            // Поле ввода никнейма
            TextBox nicknameTextBox = new TextBox();
            nicknameTextBox.Name = "nicknameTextBox";
            //nicknameTextBox.PlaceholderText = "Введите никнейм";
            nicknameTextBox.Size = new System.Drawing.Size(150, 25);
            nicknameTextBox.Location = new System.Drawing.Point(70, 220);
            this.Controls.Add(nicknameTextBox);

            // Кнопка "Зарегистрироваться"
            Button registerBtn = new Button();
            registerBtn.Text = "Зарегистрироваться";
            registerBtn.Size = new System.Drawing.Size(150, 30);
            registerBtn.Location = new System.Drawing.Point(70, 260);
            registerBtn.Click += RegisterBtn_Click;
            this.Controls.Add(registerBtn);
        }

        private void ArcadeBtn_Click(object sender, EventArgs e)
        {
            if (_currentPlayer == null)
            {
                MessageBox.Show("Пожалуйста, зарегистрируйтесь перед началом игры!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                int gameSessionId = DatabaseHelper.CreateGameSession("Arcade Session", "Arcade", _currentPlayer);
                _currentPlayer.LastGameSessionID = gameSessionId;
                this.Hide();

                using (var arcadeForm = new ArcadeForm(_currentPlayer))
                {
                    arcadeForm.ShowDialog();
                }

                this.Show(); 
            }
            
        }
        private void FPSBtn_Click(object sender, EventArgs e)
        {
            if (_currentPlayer == null)
            {
                MessageBox.Show("Пожалуйста, зарегистрируйтесь перед началом игры!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int gameSessionId = DatabaseHelper.CreateGameSession("FPS Session", "FPS", _currentPlayer);
            _currentPlayer.LastGameSessionID = gameSessionId;
            this.Hide();

            using (var fpsForm = new FPSForm(_currentPlayer))
            {
                fpsForm.ShowDialog(); 
            }

            this.Show();
        }



        private void ExitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void RegisterBtn_Click(object sender, EventArgs e)
        {
            TextBox nicknameTextBox = this.Controls["nicknameTextBox"] as TextBox;
            string nickname = nicknameTextBox?.Text.Trim();

            if (string.IsNullOrEmpty(nickname))
            {
                MessageBox.Show("Пожалуйста, введите никнейм!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                using (var connection = new Npgsql.NpgsqlConnection(DatabaseHelper.GetConnectionString()))
                {
                    connection.Open();

                    using (var cmd = new Npgsql.NpgsqlCommand(@"
                CREATE TABLE IF NOT EXISTS player (
                    id SERIAL PRIMARY KEY,
                    nickname VARCHAR(50) UNIQUE NOT NULL
                );", connection))
                    {
                        cmd.ExecuteNonQuery();
                    }

                    using (var checkCmd = new Npgsql.NpgsqlCommand("SELECT COUNT(*) FROM player WHERE nickname = @nickname", connection))
                    {
                        checkCmd.Parameters.AddWithValue("nickname", nickname);
                        long exists = (long)checkCmd.ExecuteScalar();

                        if (exists == 0)
                        {
                            using (var insertCmd = new Npgsql.NpgsqlCommand("INSERT INTO player (nickname) VALUES (@nickname)", connection))
                            {
                                insertCmd.Parameters.AddWithValue("nickname", nickname);
                                insertCmd.ExecuteNonQuery();
                                MessageBox.Show($"Пользователь \"{nickname}\" зарегистрирован!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                        else
                        {
                            MessageBox.Show($"С возвращением, {nickname}!", "Приветствие", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        _currentPlayer = new Player(nickname);
                        _currentPlayer.PlayerID = DatabaseHelper.GetPlayerIdByNickname(nickname) ?? 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка регистрации: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}