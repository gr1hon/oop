﻿using System.Windows.Forms;

namespace lab2
{
    partial class ArcadeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        /// 
        private void InitializeComponent()
        {
            this.lblScore = new System.Windows.Forms.Label();
            this.lblLevel = new System.Windows.Forms.Label();
            this.btnIncreaseScore = new System.Windows.Forms.Button();
            this.btnLevelUp = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnLoad = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.txtScoreInput = new System.Windows.Forms.TextBox();
            this.btnPause = new System.Windows.Forms.Button();
            this.lblPause = new System.Windows.Forms.Label();
            this.btnDeleteLastSave = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.Location = new System.Drawing.Point(38, 74);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(39, 16);
            this.lblScore.TabIndex = 0;
            this.lblScore.Text = "Счёт";
            // 
            // lblLevel
            // 
            this.lblLevel.AutoSize = true;
            this.lblLevel.Location = new System.Drawing.Point(38, 40);
            this.lblLevel.Name = "lblLevel";
            this.lblLevel.Size = new System.Drawing.Size(63, 16);
            this.lblLevel.TabIndex = 1;
            this.lblLevel.Text = "Уровень";
            // 
            // btnIncreaseScore
            // 
            this.btnIncreaseScore.Location = new System.Drawing.Point(31, 149);
            this.btnIncreaseScore.Name = "btnIncreaseScore";
            this.btnIncreaseScore.Size = new System.Drawing.Size(165, 35);
            this.btnIncreaseScore.TabIndex = 2;
            this.btnIncreaseScore.Text = "Увеличить счёт";
            this.btnIncreaseScore.UseVisualStyleBackColor = true;
            this.btnIncreaseScore.Click += new System.EventHandler(this.btnIncreaseScore_Click);
            // 
            // btnLevelUp
            // 
            this.btnLevelUp.Location = new System.Drawing.Point(31, 190);
            this.btnLevelUp.Name = "btnLevelUp";
            this.btnLevelUp.Size = new System.Drawing.Size(165, 35);
            this.btnLevelUp.TabIndex = 3;
            this.btnLevelUp.Text = "Следующий уровень";
            this.btnLevelUp.UseVisualStyleBackColor = true;
            this.btnLevelUp.Click += new System.EventHandler(this.btnLevelUp_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(453, 296);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(111, 35);
            this.btnSave.TabIndex = 4;
            this.btnSave.Text = "Сохранить";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnLoad
            // 
            this.btnLoad.Location = new System.Drawing.Point(453, 337);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(111, 35);
            this.btnLoad.TabIndex = 5;
            this.btnLoad.Text = "Загрузить";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(453, 378);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(111, 35);
            this.btnExit.TabIndex = 6;
            this.btnExit.Text = "Выход";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // txtScoreInput
            // 
            this.txtScoreInput.Location = new System.Drawing.Point(231, 155);
            this.txtScoreInput.Name = "txtScoreInput";
            this.txtScoreInput.Size = new System.Drawing.Size(100, 22);
            this.txtScoreInput.TabIndex = 7;
            // 
            // btnPause
            // 
            this.btnPause.Location = new System.Drawing.Point(453, 255);
            this.btnPause.Name = "btnPause";
            this.btnPause.Size = new System.Drawing.Size(111, 35);
            this.btnPause.TabIndex = 8;
            this.btnPause.Text = "Пауза";
            this.btnPause.UseVisualStyleBackColor = true;
            this.btnPause.Click += new System.EventHandler(this.btnPause_Click);
            // 
            // lblPause
            // 
            this.lblPause.AutoSize = true;
            this.lblPause.Location = new System.Drawing.Point(214, 55);
            this.lblPause.Name = "lblPause";
            this.lblPause.Size = new System.Drawing.Size(0, 16);
            this.lblPause.TabIndex = 10;
            // 
            // btnDeleteLastSave
            // 
            this.btnDeleteLastSave.Location = new System.Drawing.Point(324, 296);
            this.btnDeleteLastSave.Name = "btnDeleteLastSave";
            this.btnDeleteLastSave.Size = new System.Drawing.Size(106, 76);
            this.btnDeleteLastSave.TabIndex = 11;
            this.btnDeleteLastSave.Text = "Удалить последнее сохранение";
            this.btnDeleteLastSave.UseVisualStyleBackColor = true;
            this.btnDeleteLastSave.Click += new System.EventHandler(this.btnDeleteLastSave_Click);
            // 
            // ArcadeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 450);
            this.Controls.Add(this.btnDeleteLastSave);
            this.Controls.Add(this.lblPause);
            this.Controls.Add(this.btnPause);
            this.Controls.Add(this.txtScoreInput);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnLoad);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnLevelUp);
            this.Controls.Add(this.btnIncreaseScore);
            this.Controls.Add(this.lblLevel);
            this.Controls.Add(this.lblScore);
            this.Name = "ArcadeForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Аркада";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Label lblLevel;
        private System.Windows.Forms.Button btnIncreaseScore;
        private System.Windows.Forms.Button btnLevelUp;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox txtScoreInput;
        private System.Windows.Forms.Button btnPause;
        private System.Windows.Forms.Label lblPause;
        private Button btnDeleteLastSave;
    }
}