﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2
{
    public class Player
    {
        public Player(string nickname)
        {
            Nickname = nickname;
        }
        public int PlayerID { get; set; }
        public string Nickname { get; set; } = string.Empty;
        public int LastGameSessionID { get; set; }
    }
}
