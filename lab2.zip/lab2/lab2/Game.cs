﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace lab2
{
    public abstract class Game
    {
        protected string Title { get; set; }
        protected string Genre { get; set; }
        protected bool Paused { get; set; }
        protected Player _Player { get; set; }
        protected int GameId { get; set; }

        public Game(string title, string genre, Player player)
        {
            Title = title;
            Genre = genre;
            Paused = false;
            _Player = player;
        }

        public bool getPaused()
        {
            return Paused;
        }
        public int getGameId()
        {
            return GameId;
        }
        public void setGameId(int id)
        {
           GameId = id;
        }

        public void Pause()
        {
            Paused = true;
        }

        public void Unpause()
        {
            Paused = false;        }

        public abstract void SaveProgress();
        public abstract void LoadProgress();
    }
}