﻿using System;
using Npgsql;
using System.Configuration;

namespace lab2
{
    public static class DatabaseHelper
    {
        public static string GetConnectionString()
        {
            return ConfigurationManager.ConnectionStrings["GameDB"].ConnectionString;
        }
        public static int CreateGameSession(string title, string genre, Player player)
        {
            using (var connection = new NpgsqlConnection(GetConnectionString()))
            {
                connection.Open();

                int gameId;

                // Создаём новую игру (сеанс)
                using (var insertGameCmd = new NpgsqlCommand(
                    "INSERT INTO game (title, genre) VALUES (@title, @genre) RETURNING gameid", connection))
                {
                    insertGameCmd.Parameters.AddWithValue("title", title);
                    insertGameCmd.Parameters.AddWithValue("genre", genre);

                    gameId = Convert.ToInt32(insertGameCmd.ExecuteScalar());
                }

                // Обновляем lastgamesessionid у игрока
                using (var updatePlayerCmd = new NpgsqlCommand(
                    "UPDATE player SET lastgamesessionid = @gameId WHERE playerid = @playerId", connection))
                {
                    updatePlayerCmd.Parameters.AddWithValue("gameId", gameId);
                    updatePlayerCmd.Parameters.AddWithValue("playerId", player.PlayerID);
                    updatePlayerCmd.ExecuteNonQuery();
                }

                // Добавляем запись в gameplayer
                using (var insertGP = new NpgsqlCommand(
                    "INSERT INTO gameplayer (gameid, playerid) VALUES (@gameId, @playerId)", connection))
                {
                    insertGP.Parameters.AddWithValue("gameId", gameId);
                    insertGP.Parameters.AddWithValue("playerId", player.PlayerID);
                    insertGP.ExecuteNonQuery();
                }

                return gameId;
            }
        }
        public static int? GetPlayerIdByNickname(string nickname)
        {
            using (var connection = new NpgsqlConnection(DatabaseHelper.GetConnectionString()))
            {
                connection.Open();
                using (var command = new NpgsqlCommand("SELECT playerid FROM player WHERE nickname = @nickname", connection))
                {
                    command.Parameters.AddWithValue("@nickname", nickname);

                    var result = command.ExecuteScalar();
                    if (result != null && result != DBNull.Value)
                    {
                        return Convert.ToInt32(result);
                    }
                    else
                    {
                        return null; // Игрок с таким никнеймом не найден
                    }
                }
            }
        }

    }
}