﻿using System;
using System.Windows.Forms;

namespace lab2
{
    public partial class FPSForm : Form
    {
        private readonly FPS _fpsGame;
        public FPSForm(Player player)
        {
            InitializeComponent();
            _fpsGame = new FPS("Test Shooter", "FPS", player, 30, 55);
            _fpsGame.setGameId(player.LastGameSessionID);
            UpdateUI();
        }
        private void UpdateUI()
        {
            lblHealth.Text = $"Здоровье: {_fpsGame.GetHealth()}";
            lblAmmo.Text = $"Патроны: {_fpsGame.GetAmmo()}";
        }

        private void btnShoot_Click(object sender, EventArgs e)
        {
            if(_fpsGame.getPaused())
            {
                MessageBox.Show("Игра на паузе! Сначала снимите паузу.", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                _fpsGame.Shoot();
                if (_fpsGame.GetAmmo() == 0)
                {
                    MessageBox.Show("Патроны закончились!", "",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                UpdateUI();
            }
        }

        private void btnHeal_Click(object sender, EventArgs e)
        {
            if(_fpsGame.getPaused())
            {
                MessageBox.Show("Игра на паузе! Сначала снимите паузу.", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                _fpsGame.Heal();
                if (_fpsGame.GetHealth() == 100)
                {
                    MessageBox.Show("Вы полностью здоровы!", "",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                UpdateUI();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                _fpsGame.SaveProgress();
                MessageBox.Show("Игра успешно сохранена!", "",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения игры: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            try
            {
                _fpsGame.LoadProgress();
                UpdateUI();
                MessageBox.Show("Игра успешно загружена!", "",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки игры: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnPause_Click(object sender, EventArgs e)
        {
            if (_fpsGame.getPaused())
            {
                _fpsGame.Unpause();
                btnPause.Text = "Пауза";
                lblPause.Text = "";
            }
            else
            {
                _fpsGame.Pause();
                btnPause.Text = "Продолжить";
                lblPause.Text = "Игра на паузе!";

            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnTakeDamage_Click(object sender, EventArgs e)
        {
            if (_fpsGame.getPaused())
            {
                MessageBox.Show("Игра на паузе! Сначала снимите паузу.", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else if (int.TryParse(txtDamageInput.Text, out int damage))
            {
                _fpsGame.TakeDamage(damage);
                UpdateUI();
                if (_fpsGame.GetHealth() == 0)
                {
                    MessageBox.Show("Вы погибли! Игра окончена", "",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                txtDamageInput.Clear();
            }
            else
            {
                MessageBox.Show("Пожалуйста, введите количество урона!", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDeleteLastSave_Click(object sender, EventArgs e)
        {
            _fpsGame.DeleteLastFPSSave();
        }
    }
}
