﻿using System;
using System.Reflection.Emit;
using System.Windows.Forms;
using Npgsql;

namespace lab2
{
    public class FPS : Game
    {
        private int Ammo { get; set; }
        private int Health { get; set; }

        public FPS(string title, string genre, Player player, int ammo, int health)
            : base(title, genre, player)
        {
            Ammo = ammo;
            Health = health;
        }
        public int GetAmmo()
        {
            return Ammo;
        }
        public void SetAmmo(int ammo)
        {
            Ammo = ammo;
        }
        public int GetHealth()
        {
            return Health;
        }
        public void SetHealth(int health)
        {
            Health = health;
        }
        public void Shoot()
        {
            if (!Paused)
            {
                if (Ammo > 0)
                {
                    Ammo--;
                
                }
            }
        }
        public void Heal()
        {
            if (!Paused)
            {
                Health = Math.Min(Health + 10, 100);
            }
            
        }
        public void TakeDamage(int damage) 
        {
            if (!Paused)
            {
                if (Health > 0)
                {
                    Health = Math.Max(Health - damage, 0);
                }
            }
        }

        override public void SaveProgress()
        {
            using (var connection = new NpgsqlConnection(DatabaseHelper.GetConnectionString()))
            {
                connection.Open();
                string query;
                using (var checkCmd = new NpgsqlCommand(
                   "SELECT COUNT(*) FROM fps WHERE gameid = @game_id", connection))
                {
                    checkCmd.Parameters.AddWithValue("@game_id", GameId);
                    var count = (long)checkCmd.ExecuteScalar();

                    if (count == 0)
                    {
                        query = @"INSERT INTO fps (gameid, health, ammo, playerid) VALUES (@game_id, @health, @ammo, @player_id);";

                        using (var cmd = new NpgsqlCommand(query, connection))
                        {
                            cmd.Parameters.AddWithValue("@game_id", GameId);
                            cmd.Parameters.AddWithValue("@health", Health);
                            cmd.Parameters.AddWithValue("@ammo", Ammo);
                            cmd.Parameters.AddWithValue("@player_id", _Player.PlayerID);

                            cmd.ExecuteNonQuery();
                        }

                    }
                    else
                    {
                        query = @"UPDATE fps SET health = @health, ammo = @ammo WHERE gameid = @game_id;";

                        using (var cmd = new NpgsqlCommand(query, connection))
                        {
                            cmd.Parameters.AddWithValue("@game_id", GameId);
                            cmd.Parameters.AddWithValue("@health", Health);
                            cmd.Parameters.AddWithValue("@ammo", Ammo);

                            cmd.ExecuteNonQuery();
                        }
                    }
                }
                
            }
        }

        override public void LoadProgress()
        {
            using (var connection = new NpgsqlConnection(DatabaseHelper.GetConnectionString()))
            {
                connection.Open();

                string query = @"
            SELECT health, ammo, gameid
            FROM fps
            WHERE playerid = @player_id
            ORDER BY fpsid DESC
            LIMIT 1;";

                using (var cmd = new NpgsqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@player_id", _Player.PlayerID);

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            Health = reader.GetInt32(0);
                            Ammo = reader.GetInt32(1);
                            GameId = reader.GetInt32(2);
                            _Player.LastGameSessionID = GameId;
                        }
                        else
                        {
                            throw new Exception("У Вас нет сохранённых данных!");
                        }
                    }
                }
                using (var updatePlayerCmd = new NpgsqlCommand(
                    "UPDATE player SET lastgamesessionid = @gameId WHERE playerid = @playerId", connection))
                {
                    updatePlayerCmd.Parameters.AddWithValue("gameId", GameId);
                    updatePlayerCmd.Parameters.AddWithValue("playerId", _Player.PlayerID);
                    updatePlayerCmd.ExecuteNonQuery();
                }
            }
        }
        public void DeleteLastFPSSave()
        {
            if (_Player == null)
            {
                MessageBox.Show("Игрок не авторизован.");
                return;
            }

            using (var connection = new NpgsqlConnection(DatabaseHelper.GetConnectionString()))
            {
                connection.Open();

                // Проверяем, есть ли сохранение в arcade с этим gameid и playerid
                using (var checkCmd = new NpgsqlCommand(
                    "SELECT COUNT(*) FROM fps WHERE playerid = @pid", connection))
                {
                    checkCmd.Parameters.AddWithValue("pid", _Player.PlayerID);
                    var count = (long)checkCmd.ExecuteScalar();

                    if (count == 0)
                    {
                        MessageBox.Show("Сохранение не найдено.");
                        return;
                    }
                }

                // Удаляем строку из fps
                using (var deleteCmd = new NpgsqlCommand(
                    "DELETE FROM fps WHERE fpsid = (" +
                    "SELECT fpsid FROM fps WHERE " +
                    "playerid = @pid ORDER BY fpsid DESC LIMIT 1 )", connection))
                {
                    deleteCmd.Parameters.AddWithValue("pid", _Player.PlayerID);
                    deleteCmd.ExecuteNonQuery();
                }

                // Обнуляем lastgamesessionid у игрока
                using (var updateCmd = new NpgsqlCommand(
                    "UPDATE player SET lastgamesessionid = NULL WHERE playerid = @pid", connection))
                {
                    updateCmd.Parameters.AddWithValue("pid", _Player.PlayerID);
                    updateCmd.ExecuteNonQuery();
                }

                MessageBox.Show("Последнее сохранение успешно удалено.");
            }
        }
    }
}