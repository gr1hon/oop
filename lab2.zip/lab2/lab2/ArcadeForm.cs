﻿using System;
using System.Windows.Forms;

namespace lab2
{
    public partial class ArcadeForm : Form
    {
        private readonly Arcade _arcadeGame;

        public ArcadeForm(Player player)
        {
            InitializeComponent();
            _arcadeGame = new Arcade("Test Arcade", "Arcade", player, 0, 1);
            _arcadeGame.setGameId(player.LastGameSessionID);
            UpdateUI();
        }

        private void UpdateUI()
        {
            lblScore.Text = $"Счёт: {_arcadeGame.GetScore()}";
            lblLevel.Text = $"Уровень: {_arcadeGame.GetLevel()}";
        }

        private void btnIncreaseScore_Click(object sender, EventArgs e)
        {   
            if(_arcadeGame.getPaused())
            {
                MessageBox.Show("Игра на паузе! Сначала снимите паузу.", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else if (int.TryParse(txtScoreInput.Text, out int points))
            {
                _arcadeGame.IncreaseScore(points);
                UpdateUI();
                txtScoreInput.Clear();
            }
            else
            {
                MessageBox.Show("Пожалуйста, введите количество очков!", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLevelUp_Click(object sender, EventArgs e)
        {
            if (_arcadeGame.getPaused())
            {
                MessageBox.Show("Игра на паузе! Сначала снимите паузу.", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                _arcadeGame.NextLevel();
                UpdateUI();
            }
                
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                _arcadeGame.SaveProgress();
                MessageBox.Show("Игра успешно сохранена!", "",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения игры: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            try
            {
                _arcadeGame.LoadProgress();
                UpdateUI();
                MessageBox.Show("Игра успешно загружена!", "",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки игры: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnPause_Click(object sender, EventArgs e)
        {
            if (_arcadeGame.getPaused())
            {
                _arcadeGame.Unpause();
                btnPause.Text = "Пауза";
                lblPause.Text = "";
            }
            else
            {
                _arcadeGame.Pause();
                btnPause.Text = "Продолжить";
                lblPause.Text = "Игра на паузе!";

            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDeleteLastSave_Click(object sender, EventArgs e)
        {
            _arcadeGame.DeleteLastArcadeSave();
        }
    }
}